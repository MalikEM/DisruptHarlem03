# Welcome Disrupt Harlem Coding Squad!!

This will be your class' personal GitHub acccount, in which you will find helpful materials and your classmates projects from this program.
